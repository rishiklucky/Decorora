import React, { Component } from 'react'
import Header from './Header'
import '../styles/body.css'

export default class Products extends Component {
    constructor(){
        super();

        let userEmailId = localStorage.getItem("emailId");
        // let userName = localStorage.getItem("name");
        // let Products = localStorage.getItem("products");
        // let items = JSON.parse(Products);
        // console.log(items);

        this.state = {
            emailId : userEmailId,
            // name : userName,
            cartItems : [],
            products : [
              {
    "id":1,
    "name": "Vintage Wall Clock",
    "description": "A classic vintage wall clock with Roman numerals to add a timeless touch to your living space.",
    "price": 1299,
    "image": "https://www.homeartisan.in/cdn/shop/files/HAWC-2305_1_5e9a5a97-61a5-4180-9fe4-878425f1b657.jpg?v=1721646948"
  },
  {
    "id":2,
    "name": "Macrame Wall Hanging",
    "description": "Handmade boho macrame wall hanging perfect for bedrooms or cozy corners.",
    "price": 899,
    "image": "https://m.media-amazon.com/images/I/71FBrB6Z6QL.jpg"
  },
  {
    "id":3,
    "name": "Ceramic Flower Vase",
    "description": "Elegant ceramic flower vase with a glossy white finish, ideal for center tables.",
    "price": 749,
    "image": "https://nostalgiahomes.com/cdn/shop/products/IMG_2742.jpg?v=1671168233"
  },
  {
    "id":4,
    "name": "Abstract Canvas Painting",
    "description": "Modern abstract art canvas to give your walls a contemporary uplift.",
    "price": 1999,
    "image": "https://kotart.in/cdn/shop/files/CanvasCS2468.jpg?v=1698337622"
  },
  {
    "id":5,
    "name": "Wooden Table Lamp",
    "description": "Minimalist wooden table lamp with warm LED light .",
    "price": 1499,
    "image": "https://m.media-amazon.com/images/I/71XOQxUfG2L.jpg"
  },
  {
    "id":6,
    "name": "Decorative Cushions Set",
    "description": "Set of 5 colorful decorative cushions made with soft velvet fabric.",
    "price": 999,
    "image": "https://cdn.shopify.com/s/files/1/0632/2526/6422/files/cushion-cover-sets-denara-cushion-cover-set-of-five-1.jpg?v=1753158624"
  },
  {
    "id":7,
    "name": "Aroma Scented Candles",
    "description": "Pack of 2 aroma candles with lavender, vanilla, and sandalwood scents.",
    "price": 599,
    "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZgqIVy8VugjG7oxgm145K9NfGeA69mDMdgw&s"
  },
  {
    "id":8,
    "name": "Woven Storage Basket",
    "description": "Eco-friendly handwoven basket great for storing magazines or throws.",
    "price": 499,
    "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKCcBdXz7syHVy8JwT69yBcSXrKOwdh4tL6g&s"
  },
  {
    "id":9,
    "name": "Framed Nature Prints",
    "description": "Set of 3 Landscape Nature Artistic Framed prints to bring nature indoors.",
    "price": 1199,
    "image": "https://artstreet.in/cdn/shop/products/2_d86c0905-7456-4651-86f0-e01f4f29e960_700x700.jpg?v=1687589840"
  }
            ],
        }
        // localStorage.setItem("products",JSON.stringify(this.state.products));

    }


    clearData(){
        this.setState({
            products : []
        });
    }

    addToCart = (prod) =>{
        alert(`Item Added to Cart!`);
        this.state.cartItems.push(prod);
        localStorage.setItem("cartItems",JSON.stringify(this.state.cartItems))
        console.log(this.state.cartItems);
    }
  render() {
    return (
       
        <div className='bbody'>
              <Header></Header>
      
      <div class="container">
      
        {/* <h2 align="left">Welcome {this.state.name}!</h2> */}
        <h1 align='center'style={{color:"#8b4513",fontFamily:"monospace"}}>Products</h1> <br/>
        <div class="row">
          {
            this.state.products.map((prod)=>(
              <div class='col-md-4'>   
<div
  className="card"
  style={{
    width: '300px',
    height: '430px',
    textAlign: 'center',
    margin: '10px',
    border: '3px solid #8b4513',
    borderRadius: '3%',
    background: 'rgba(255, 255, 255, 0.2)',
    backdropFilter: 'blur(10px)',
    WebkitBackdropFilter: 'blur(10px)', 
    color: '#000', 
    fontFamily:"monospace",
  }}
>          <img src={prod.image} className="card-img-top mx-auto d-block" alt="Cart Image" style={{width:"150px",height:"150px",marginTop:"10px",border:"3px",borderStyle:"solid",borderColor:"#8b4513",borderRadius:"10%"}}/>
          <div className="card-body">
            <h4 className="card-title">{prod.name}</h4>
            <p className="card-text">{prod.description}</p>
            <p className='card-text'>Price: ₹{prod.price}/-</p>
            <p align="center">
              <button onClick={() => this.addToCart(prod)} class="btn" style={{color:"black",backgroundColor:"#8b4513",border:"3px",borderStyle:"solid",borderColor:"#8b4513",borderRadius:"5%",borderColor:"#8b4513",}}>Add To Cart</button>
            </p>
          </div>
        </div>
              </div>
            ))
          }
        </div>
        </div>
          </div>
    )
  }
}
