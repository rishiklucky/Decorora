import React, { Component } from 'react'

export default class Logout extends Component {

    constructor(){
        super();

        localStorage.removeItem('emailId');
        localStorage.clear();

        window.open('/','_self');
    }
  render() {
    return (
      <body style={{backgroundImage:"url('/bg.png')", textAlign:'center'}}>
        <h1>Logout Component</h1>
      </body>
    )
  }
}
