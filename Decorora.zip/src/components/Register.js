import React, { Component } from 'react'
import '../styles/Register.css';


export default class Register extends Component {
    constructor(){
        super();
        
        this.name=React.createRef();
        this.emailId=React.createRef();
        this.password=React.createRef();
    }

    registerUser = () =>{
        const user = {
            name : this.name.current.value,
            emailId : this.emailId.current.value,
            password : this.password.current.value,
        }

        console.log("User Details");
        console.log(user);
        alert(`Registered Successfully`);
    }
  render() {
    return (
      <div className="register-container" style={{border:"3px",borderStyle:"solid",backgroundColor:"salmon",borderColor:"lightgrey",borderRadius:"3%"}}>
        <div className="register-title" style={{color:"lightgrey"}}>Register</div>
        <form className="register-form">
          <table className="register-table">
            <tbody>
              <tr>
                <th><label htmlFor="empname" style={{color:"lightgrey"}}>Name:</label></th>
                <td><input  style={{border:"3px",borderStyle:"solid",borderColor:"lightgrey"}} type="text" id="empname" name="empname" ref={this.name}required /></td>
              </tr>
              <tr>
                <th><label htmlFor="email" style={{color:"lightgrey"}}>Email:</label></th>
                <td><input  style={{border:"3px",borderStyle:"solid",borderColor:"lightgrey"}} type="email" id="email" name="email" ref={this.emailId} required /></td>
              </tr>
              <tr>
                <th><label htmlFor="password" style={{color:"lightgrey"}}>Password:</label></th>
                <td><input  style={{border:"3px",borderStyle:"solid",borderColor:"lightgrey"}} type="password" id="password" name="password" ref={this.password} required /></td>
              </tr>
              <tr>
                <td colSpan="2" style={{textAlign:'center'}}>
                  <button className="register-btn" style={{color:"salmon",backgroundColor:"lightgrey"}} type="button" onClick={()=>this.registerUser()}>Register</button>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
    )
  }
}
