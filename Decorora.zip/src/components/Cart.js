import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Products from './Products';
import Header from './Header';

export default class Cart extends Component {
    constructor(){
        super();
        let cartProducts = localStorage.getItem("cartItems");
        let cartItems = JSON.parse(cartProducts);
        console.log(cartItems);
        
        this.state={
            total:0,
            products:cartItems,

        }
    }

    purchase = () =>{
        alert(`Thank You For Purchase`);
        localStorage.removeItem("cartItems");
        this.setState({
            products:null,
        })
    }
  render() {
    if(this.state.products != null){

      this.state.products.map((product)=>{
        this.state.total += product.price;
      })
      return(
        <div>
            {/* <Header></Header> */}
          {/* <h3 align="left" style = {{color:'blue'}}>Welcome {this.state.emailId} !</h3> */}
          <h2 align="center" style={{color:"salmon"}}> {this.state.emailId} Cart Items </h2>

        <table class="table table-bordered">
        
          <thead class=' text-white text-center' style={{backgroundColor:"salmon"}}>
              <th>Product Name</th>
              <th>Product Description</th>
              <th>Product Image</th>
              <th>Price</th>
          </thead>

          <tbody>
            {
              this.state.products.map((product) => (
                <tr>
                  <td align="center">{product.name}</td>
                  <td align="center">{product.description}</td>
                  <td align="center"><img src={product.image} height="100px" width="100px" /></td>
                  <td align="center">₹{product.price} /-</td>                  
                </tr>
              ))
            }

            <tr>
              <td colSpan="3" align="Right"><b>Total:</b></td>
              <td align="center"><b>₹{this.state.total}/-</b></td>
            </tr>

            <tr>
              <td colSpan="3"></td>
              <td align="center">
                <button class="btn " style={{backgroundColor:"salmon"}} onClick={()=>this.purchase()}>Pruchase</button>
              </td>
            </tr>

          </tbody>
        </table>
        </div>
      )
    }
    else{
      return(
        <div>
      <h3 style={{color:'salmon'}}>Cart is Empty!</h3>
      </div>
      )
    }
  }
}
