import React, { Component } from 'react'

export default class EditProduct extends Component {
  render() {
    return (
      <div>
        edit page
      </div>
    )
  }
}
