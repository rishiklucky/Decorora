import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Header from './components/Header';
import Login from './components/Login';
import Register from './components/Register';
import Products from './components/Products';
import Logout from './components/Logout';
import Cart from './components/Cart';
import AdminDashboard from './components/AdminDashboard';
import AdminLogin from './components/AdminLogin';


function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Login/>}/>;
      <Route path='/register' element={<Register/>}/>;
      <Route path='/products' element={<Products/>}/>;
      <Route path='/logout' element={<Logout/>}/>;
      <Route path='/cart' element={<Cart/>}/>;
      <Route path='/adminlogin' element={<AdminLogin/>}/>;
      <Route path='/admindashboard' element={<AdminDashboard/>}/>;     

      </Routes>
      </BrowserRouter>
  );
}

export default App;
