import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import '../styles/Login.css';

export default class AdminLogin extends Component {
    constructor(){
        super();

        this.state={
            admins:[
                {name:'rishik',emailId:'rishik@gmail.com',password:123},
            ]
        }

        this.emailId=React.createRef();
        this.password=React.createRef();
    }

    loginSubmit = () =>{
        let adminemailId = this.emailId.current.value;
        let password = this.password.current.value;
        // let Uname = this.state.users.name;
        let Admin = null;

        localStorage.setItem("adminemailId",adminemailId);
        // localStorage.setItem("name",Uname);

        this.state.admins.map((admin)=>{
            if(admin.emailId == adminemailId && admin.password == password){
                Admin = admin;
                console.log(admin);
                window.open('/admindashboard','_self');
            }
            else{
                alert(`Invalid Credentils!`);
                console.log('Invalid Credentils');
            }
        })
    }

  render() {
    return (
      // <div style={{backgroundImage:"url('https://plus.unsplash.com/premium_photo-1670360414946-e33a828d1d52?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9tZSUyMGRlY29yfGVufDB8fDB8fHww')"}}>
      <div className="login-container" style={{border:"3px",borderStyle:"solid",backgroundColor:"salmon",borderColor:"lightgray",borderRadius:"3%"}}>
        <div className="login-title" style={{color:"lightgrey"}}>Admin Login</div>
        <form className="login-form">
          <div className="login-field">
            <label htmlFor="email" style={{color:"lightgrey"}}>Email Id:</label>
            <input style={{border:"3px",borderStyle:"solid",borderColor:"lightgrey"}} type="email" id="email" name="email"  ref={this.emailId} required />
          </div>
          <div className="login-field">
            <label htmlFor="password" style={{color:"lightgrey"}}>Password:</label>
            <input  style={{border:"3px",borderStyle:"solid",borderColor:"lightgrey"}}  type="password" id="password" name="password" ref={this.password} required />
          </div>
          <div className="login-actions">
            <button className="login-btn" style={{color:"salmon",backgroundColor:"lightgrey"}} type="button" onClick={()=>this.loginSubmit()}>Login</button>
          </div>
          <div className="login-signup">
            Don't have an account? <Link to="/register" style={{color:"lightgrey"}}>Sign Up</Link>
          </div>
        </form>
      </div>
      // </div>
    )
  }
}
