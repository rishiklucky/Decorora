import React, { Component } from 'react'

export default class DeleteProduct extends Component {
  render() {
    return (
      <div>
        Delete Page
      </div>
    )
  }
}
