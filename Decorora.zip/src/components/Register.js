import React, { Component } from 'react'
import '../styles/Register.css';


export default class Register extends Component {
    constructor(){
        super();
        
        this.name=React.createRef();
        this.emailId=React.createRef();
        this.password=React.createRef();
    }

    registerUser = () =>{
        const user = {
            name : this.name.current.value,
            emailId : this.emailId.current.value,
            password : this.password.current.value,
        }

        console.log("User Details");
        console.log(user);
        alert(`Registered Successfully`);
    }
  render() {
    return (
      <div style={{
     backgroundImage:"url('./bg.png')",
     backgroundSize: 'cover',
     backgroundPosition: 'center',
     backgroundRepeat: 'no-repeat',
     height: '100vh',
     width: '100vw',
     display: 'flex',
     justifyContent: 'center',
     alignItems: 'center',
   }}>
      <div className="register-container" style={{border:"3px",borderStyle:"solid",background: 'rgba(255, 255, 255, 0.2)',borderColor:"#8b4513",borderRadius:"3%",backdropFilter: 'blur(10px)',WebkitBackdropFilter: 'blur(10px)', color: '#000' }}>
        <div className="register-title" style={{color:"#8b4513"}}>Register</div>
        <form className="register-form">
          <table className="register-table">
            <tbody>
              <tr>
                <th><label htmlFor="empname" style={{color:"#8b4513"}}>Name:</label></th>
                <td><input  style={{border:"3px",borderStyle:"solid",borderColor:"#8b4513",backgroundColor:"transparent"}} type="text" id="empname" name="empname" ref={this.name}required /></td>
              </tr>
              <tr>
                <th><label htmlFor="email"style={{color:"#8b4513"}}>Email:</label></th>
                <td><input  style={{border:"3px",borderStyle:"solid",borderColor:"#8b4513",backgroundColor:"transparent"}} type="email" id="email" name="email" ref={this.emailId} required /></td>
              </tr>
              <tr>
                <th><label htmlFor="password" style={{color:"#8b4513"}}>Password:</label></th>
                <td><input style={{border:"3px",borderStyle:"solid",borderColor:"#8b4513",backgroundColor:"transparent"}}type="password" id="password" name="password" ref={this.password} required /></td>
              </tr>
              <tr>
                <td colSpan="2" style={{textAlign:'center'}}>
                  <button className="register-btn" style={{color:"black",backgroundColor:"#8b4513",border:"3px",borderStyle:"solid",borderColor:"#8b4513"}}type="button" onClick={()=>this.registerUser()}>Register</button>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
      </div>
    )
  }
}
