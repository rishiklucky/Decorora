import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import '../styles/Login.css';
export default class Login extends Component {
    constructor(){
        super();

        this.state={
            users:[
                {name:'rishik',emailId:'rishik@gmail.com',password:123},
            ]
        }

        this.emailId=React.createRef();
        this.password=React.createRef();
    }

    loginSubmit = () =>{
        let emailId = this.emailId.current.value;
        let password = this.password.current.value;
        // let Uname = this.state.users.name;
        let User = null;

        localStorage.setItem("emailId",emailId);
        // localStorage.setItem("name",Uname);

        this.state.users.map((user)=>{
            if(user.emailId == emailId && user.password == password){
                User = user;
                console.log(user);
                window.open('/products','_self');
            }
            else{
                alert(`Invalid Credentils!`);
                console.log('Invalid Credentils');
            }
        })
    }

  render() {
    return (
  <div style={{
     backgroundImage:"url('/bg.png')",
     backgroundSize: 'cover',
     backgroundPosition: 'center',
     backgroundRepeat: 'no-repeat',
     height: '100vh',
     width: '100vw',
     display: 'flex',
     justifyContent: 'center',
     alignItems: 'center',
   }}>
      <div className="login-container" style={{border:"3px",borderStyle:"solid",background: 'rgba(255, 255, 255, 0.2)',borderColor:"#8b4513",borderRadius:"3%",backdropFilter: 'blur(10px)',WebkitBackdropFilter: 'blur(10px)', color: '#000' }}>
        <div className="login-title" style={{color:"#8b4513"}}>Login</div>
        <form className="login-form">
          <div className="login-field">
            <label htmlFor="email" style={{color:"#8b4513"}}>Email Id:</label>
            <input  type="email" id="email" name="email"  ref={this.emailId} required  style={{border:"3px",borderStyle:"solid",borderColor:"#8b4513",backgroundColor:"transparent"}} />
          </div>
          <div className="login-field">
            <label htmlFor="password" style={{color:"#8b4513"}}>Password:</label>
            <input    type="password" id="password" name="password" ref={this.password} required style={{border:"3px",borderStyle:"solid",borderColor:"#8b4513",backgroundColor:"transparent"}} />
          </div>
          <div className="login-actions">
            <button className="login-btn" style={{color:"black",backgroundColor:"#8b4513",border:"3px",borderStyle:"solid",borderColor:"#8b4513"}} type="button" onClick={()=>this.loginSubmit()}>Login</button>
          </div>
          <div className="login-signup">
            Don't have an account? <Link to="/register" style={{color:"#8b4513"}}>Sign Up</Link>
          </div>
        </form>
      </div>
      </div>
    )
  }
}
