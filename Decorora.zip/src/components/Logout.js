import React, { Component } from 'react'

export default class Logout extends Component {

    constructor(){
        super();

        localStorage.removeItem('emailId');
        localStorage.clear();

        window.open('/','_self');
    }
  render() {
    return (
      <div>
        <h1>Logout component</h1>
      </div>
    )
  }
}
