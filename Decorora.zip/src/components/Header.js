
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

export default class Header extends Component {
  constructor(props) {
    super(props);
     let userEmailId = localStorage.getItem('emailId');
    this.state = { isCollapsed: true,
      emailId:userEmailId,
     };
    }
   

  handleToggle = () => {
    this.setState(prev => ({ isCollapsed: !prev.isCollapsed }));
  };

  handleLinkClick = () => {
    this.setState({ isCollapsed: true });
  };

  render() {
    return (
      <nav className="navbar navbar-expand-lg navbar-dark" style={{backgroundColor:"salmon",border:"3px",borderStyle:"solid",borderColor:"lightgrey",borderColor:"lightgray"}}>
        <div className="container-fluid">
          <Link className="navbar-brand" to="/" ><i>Decorora</i></Link>
          {/* <span className='navbar-brand'>welcome {this.state.emailId}</span> */}
          <button className="navbar-toggler" type="button" onClick={this.handleToggle} aria-controls="navbarNav" aria-expanded={!this.state.isCollapsed} aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className={`collapse navbar-collapse${this.state.isCollapsed ? '' : ' show'}`} id="navbarNav">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <Link className="nav-link" to="/cart" onClick={this.handleLinkClick}>Cart</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/logout" onClick={this.handleLinkClick}>Logout</Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    );
  }
}
